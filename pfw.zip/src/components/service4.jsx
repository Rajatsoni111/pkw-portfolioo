import React from 'react'

const Service4 = () => {
  return (
    <div className='service1'>
      <img src="../Icon Design/p.png" alt="" />
      <img src="../Icon Design/q.png" alt="" />
      <img src="../Icon Design/r.png" alt="" />
      <img src="../Icon Design/s.png" alt="" />
      <img src="../Icon Design/t.png" alt="" />

    </div>
  )
}

export default Service4
