import React from 'react'
import './stylesheet/service1.css'

const Service1 = () => {
  return (
    <div className='service1'>
      <img src="../Logo and Branding/1.png" alt="" />
      <img src="../Logo and Branding/2.png" alt="" />
      <img src="../Logo and Branding/3.png" alt="" />
      <img src="../Logo and Branding/4.png" alt="" />
      <img src="../Logo and Branding/5.png" alt="" />

    </div>
  )
}

export default Service1
