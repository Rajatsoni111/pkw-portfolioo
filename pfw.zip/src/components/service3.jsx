import React from 'react'

const Service3 = () => {
  return (
    <div className='service1'>
      <img src="../Art and Illustration/a.png" alt="" />
      <img src="../Art and Illustration/b.png" alt="" />
      <img src="../Art and Illustration/c.png" alt="" />
      <img src="../Art and Illustration/d.png" alt="" />
      <img src="../Art and Illustration/e.png" alt="" />
    </div>
  )
}

export default Service3
