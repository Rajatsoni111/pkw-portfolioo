import React from 'react'

const Service2 = () => {
  return (
    <div className='service1'>
      <img src="../Book Layout/A.png" alt="" />
      <img src="../Book Layout/B.png" alt="" />
      <img src="../Book Layout/C.png" alt="" />
      <img src="../Book Layout/D.png" alt="" />
      <img src="../Book Layout/E.png" alt="" />

    </div>
  )
}

export default Service2
